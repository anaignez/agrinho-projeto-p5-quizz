//uso com Ia: chatgpt 
//consumo consciente
//Eu e meus amigos do bairro estávamos brincando em um dia qualquer, quando começamos a perceber o quanto a água era desperdiçada enquanto a vizinha limpava a calçada. Nisso, decidimos tentar calcular quanto de água ela gastaria se limpasse a calçada quatro vezes por semana.
//Meus amigos, Andréa, Isabelly, Júlia e Alessandro, estavam comigo. A Andréa é morena, tem olhos castanhos e cabelo cacheado. Ela tem 15 anos e seu estilo de roupa varia entre peças largas e, às vezes, mais justas. Não é muito fã de maquiagem, mas é muito engraçada e esperta.
//A Isabelly é parda, tem olhos castanhos escuros e cabelo ondulado. Ela adora roupas largas e ama maquiagem. É engraçada, mas às vezes é misteriosa. Também é muito carinhosa e esperta.
//A Júlia tem 18 anos, cabelo ruivo e olhos castanhos. Ela prefere roupas mais justas e é engraçada, inteligente e ciumenta com suas amizades.
//O Alessandro tem 14 anos, olhos castanhos e costuma usar roupas do seu tamanho. Ele é muito inteligente e misterioso, especialmente com pessoas que acaba de conhecer. faca um quizz ensino medio para p5.js
let tela = "capa";
let perguntaAtual = 0;
let pontuacao = 0;
let mostrarFeedback = false;
let respostaCerta = false;

let perguntas = [
  {
    texto: "Qual atitude ajuda a economizar água em casa?",
    opcoes: ["Tomar banho de 30 minutos", "Usar mangueira para lavar calçada", "Fechar a torneira ao escovar os dentes", "Lavar o carro com mangueira"],
    correta: 2
  },
  {
    texto: "Quanto de água pode ser desperdiçado ao escovar os dentes com a torneira aberta?",
    opcoes: ["2 litros", "10 litros", "20 litros", "até 80 litros"],
    correta: 3
  },
  {
    texto: "Qual desses hábitos ajuda a economizar energia elétrica?",
    opcoes: ["Deixar luzes acesas o dia todo", "Desligar aparelhos da tomada quando não usados", "Ligar todos os ventiladores da casa", "Abrir a geladeira com frequência"],
    correta: 1
  },
  {
    texto: "Reciclar papel ajuda a:",
    opcoes: ["Gastar mais energia", "Evitar o desmatamento", "Poluir os rios", "Nada muda"],
    correta: 1
  },
  {
    texto: "Qual personagem é misteriosa e ama maquiagem?",
    opcoes: ["Andréa", "Isabelly", "Júlia", "Alessandro"],
    correta: 1
  },
  {
    texto: "Quantas vezes por semana a vizinha limpava a calçada?",
    opcoes: ["1", "2", "3", "4"],
    correta: 3
  },
  {
    texto: "Qual a atitude mais sustentável para o transporte diário?",
    opcoes: ["Usar carro sozinho", "Ir a pé ou de bicicleta", "Pegar carona com 3 carros", "Ir de moto sozinho"],
    correta: 1
  },
  {
    texto: "O que é consumo consciente?",
    opcoes: ["Comprar por impulso", "Consumir sem pensar no impacto", "Refletir sobre o impacto de nossas escolhas", "Ignorar desperdícios"],
    correta: 2
  },
  {
    texto: "Desperdício de alimentos está ligado a:",
    opcoes: ["Economia", "Sustentabilidade", "Desperdício de recursos naturais", "Boas práticas"],
    correta: 2
  },
  {
    texto: "Qual destas atitudes reduz a produção de lixo?",
    opcoes: ["Usar descartáveis sempre", "Reutilizar embalagens", "Jogar tudo no lixo comum", "Não separar recicláveis"],
    correta: 1
  },
  {
    texto: "Quem é ruiva e ciumenta com as amizades?",
    opcoes: ["Isabelly", "Andréa", "Júlia", "Alessandro"],
    correta: 2
  },
  {
    texto: "O que é compostagem?",
    opcoes: ["Lavar roupas com compostos", "Misturar lixo comum", "Transformar resíduos orgânicos em adubo", "Descartar pilhas no vaso sanitário"],
    correta: 2
  },
  {
    texto: "Reduzir o uso de plástico ajuda a:",
    opcoes: ["Aumentar poluição", "Melhorar a qualidade do ar", "Proteger animais e oceanos", "Encher mais os aterros"],
    correta: 2
  },
  {
    texto: "Qual personagem é inteligente e misterioso?",
    opcoes: ["Andréa", "Alessandro", "Júlia", "Isabelly"],
    correta: 1
  },
  {
    texto: "Desligar a luz ao sair de um cômodo é um exemplo de:",
    opcoes: ["Gasto extra", "Desperdício", "Consumo consciente", "Atitude irresponsável"],
    correta: 2
  },
  {
    texto: "Qual alternativa representa os 3 Rs da sustentabilidade?",
    opcoes: ["Reduzir, Reutilizar, Reciclar", "Reclamar, Reaproveitar, Reparar", "Repetir, Recusar, Reformar", "Renovar, Reduzir, Rezar"],
    correta: 0
  },
  {
    texto: "Economizar água ajuda principalmente a:",
    opcoes: ["Ter mais chuvas", "Evitar o racionamento e preservar rios", "Gastar mais luz", "Desligar torneiras"],
    correta: 1
  },
  {
    texto: "Comprar apenas o necessário é uma atitude de:",
    opcoes: ["Gasto consciente", "Desperdício", "Exagero", "Insegurança"],
    correta: 0
  },
  {
    texto: "Lâmpadas fluorescentes consomem menos energia que:",
    opcoes: ["Lâmpadas LED", "Lâmpadas incandescentes", "Celulares", "Micro-ondas"],
    correta: 1
  },
  {
    texto: "Qual é a melhor opção para economia de papel?",
    opcoes: ["Imprimir tudo", "Usar frente e verso", "Desperdiçar cadernos", "Rasgar folhas novas"],
    correta: 1
  }
];

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
  textSize(20);
}

function draw() {
  background(220);
  
  if (tela === "capa") {
    mostrarCapa();
  } else if (tela === "quiz") {
    mostrarPergunta();
  } else if (tela === "fim") {
    mostrarFim();
  }
}

function mostrarCapa() {
  background(100, 200, 250);
  textSize(32);
  fill(255);
  text("Quiz - Consumo Consciente", width / 2, height / 3);
  rectMode(CENTER);
  fill(0, 150, 0);
  rect(width / 2, height / 2, 200, 50);
  fill(255);
  textSize(20);
  text("Começar", width / 2, height / 2);
}

function mousePressed() {
  if (tela === "capa" && mouseX > width / 2 - 100 && mouseX < width / 2 + 100 && mouseY > height / 2 - 25 && mouseY < height / 2 + 25) {
    tela = "quiz";
  } else if (tela === "quiz") {
    if (!mostrarFeedback) {
      let p = perguntas[perguntaAtual];
      for (let i = 0; i < p.opcoes.length; i++) {
        let x = width / 2 - 150;
        let y = 150 + i * 80;
        if (mouseX > x && mouseX < x + 300 && mouseY > y && mouseY < y + 60) {
          respostaCerta = (i === p.correta);
          if (respostaCerta) pontuacao++;
          mostrarFeedback = true;
        }
      }
    } else {
      mostrarFeedback = false;
      perguntaAtual++;
      if (perguntaAtual >= perguntas.length) {
        tela = "fim";
      }
    }
  }
}

function mostrarPergunta() {
  let p = perguntas[perguntaAtual];
  textSize(22);
  fill(0);
  text(p.texto, width / 2, 100);
  
  for (let i = 0; i < p.opcoes.length; i++) {
    fill(200);
    rect(width / 2 - 150, 150 + i * 80, 300, 60);
    fill(0);
    text(p.opcoes[i], width / 2, 180 + i * 80);
  }

  if (mostrarFeedback) {
    fill(respostaCerta ? "green" : "red");
    textSize(26);
    text(respostaCerta ? "Certo!" : "Errado!", width / 2, 500);
    textSize(20);
    text("Clique para continuar", width / 2, 540);
  }
}

function mostrarFim() {
  background(0, 100, 150);
  fill(255);
  textSize(32);
  text("Fim do Quiz!", width / 2, 200);
  textSize(24);
  text("Você acertou " + pontuacao + " de " + perguntas.length + " perguntas.", width / 2, 260);
}

